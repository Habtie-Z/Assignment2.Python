#Convert Celsius to Fahrenheit
celsius = eval(input("Enter the celsius value: "))

#calculate the fahrenheit value

fahrenheit = (9/5)*celsius + 32
print("The fahrenheit value is", fahrenheit) 


