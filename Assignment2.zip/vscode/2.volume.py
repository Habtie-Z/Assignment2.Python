#Compute the volume of a cylinder

radius = eval(input("Enter the rdius: "))
length = eval(input("Enter the length of cylinder: "))

#constant
π = 3.1417

#Clculate area
area = radius * radius * π

#Clculate volume
volume = area * length

areaVol = "The area of the cylinder is {:.4f} square unit. The volume of the cylinder is {:.1f} cubic unit."
print(areaVol.format(area, volume))


