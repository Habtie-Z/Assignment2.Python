#Convert feet into meters

feet = eval(input("Enter the feet: "))

#constant
k = 0.305

#Convert feet into meters
meters = k * feet


print(feet,"feet is", meters, 'meters')


