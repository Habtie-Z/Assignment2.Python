#Convert pounds into kilograms


pounds = eval(input("Enter the pounds: "))

#constant
k = 0.454

#Convert pounds into kilograms
kilograms = k * pounds


print(pounds, "pounds is", kilograms, 'kilograms')
