#calculate tips


subtotal = eval(input("Enter the subtotal: "))

#gratuity percentage (15% = 0.15)
k = 0.15

#calculate gratuity and total
gratuity = k * subtotal
total = subtotal + gratuity

gratTot = "The gratuity is {:.2f} and the total is {:.2f}."
print(gratTot.format(gratuity, total))
