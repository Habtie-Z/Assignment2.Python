#Convert minutes into years and/days

minutes =int(input('Enter the minutes to convert: '))
years = int(minutes//(365 * 24 * 60))

remaningMinutes = minutes %(365 * 24 *60) 
days = int(remaningMinutes //(24*60))

print("{} minutes is approximatly {} years and {} days".format(minutes,years,days))

