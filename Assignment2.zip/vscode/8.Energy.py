#Calculate energy

M =  eval(input("Enter the amount of water in kilograms: "))
initialTemperature = eval(input("Enter the initialTemperature: "))
finalTemperature  = eval(input("Enter the finalTemperature: "))

Q = M * (finalTemperature - initialTemperature) * 4184

print("The energy needed is", Q) 