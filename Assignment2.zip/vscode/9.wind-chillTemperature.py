#Calculate energy

Ta = eval(input("Enter the outside temperature in Fahrenheit : "))
V = eval(input("Enter the wind speed in miles per hour: ")) 

Twc = 35.74 + 0.6215*Ta - 35.75*(V**0.16) + 0.4275*Ta*(V**0.16)
windTemp = "The wind-chill index is {:.5f}."
print(windTemp.format(Twc))